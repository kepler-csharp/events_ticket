
@extends('layouts.app')
@section('title', 'Seleccionar Asientos')

@section('content')
    <style>
        .seats-layout {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 2rem;
            margin-bottom: 2rem;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--color-primary);
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 2rem;
            transition: var(--transition);
        }

        .back-button:hover {
            gap: 1rem;
        }

        /* Seats Container */
        .seats-container {
            background: rgba(255,255,255,.96);
            padding: 2rem;
            border-radius: 18px;
            box-shadow: 0 14px 35px rgba(60,64,68,.08);
        }

        .seats-container h2 {
            font-size: 1.5rem;
            color: var(--color-dark);
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        /* Seats Map Container */
        #seat-map {
            background: linear-gradient(135deg, #f8f7f6 0%, #f0f0f0 100%);
            border-radius: 8px;
            padding: 2rem;
            min-height: 400px;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 2px dashed var(--color-light);
        }

        .seats-legend {
            display: flex;
            gap: 2rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            justify-content: center;
            font-size: 0.9rem;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .legend-seat {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            border: 2px solid #ddd;
        }

        .legend-seat.available {
            background: #4CAF50;
            border-color: #388E3C;
        }

        .legend-seat.occupied {
            background: #f44336;
            border-color: #d32f2f;
        }

        .legend-seat.selected {
            background: #FD7B41;
            border-color: #ff6f2a;
        }

        /* Showtime Info Sidebar */
        .showtime-info {
            background: rgba(255,255,255,.96);
            padding: 2rem;
            border-radius: 18px;
            box-shadow: 0 14px 35px rgba(60,64,68,.08);
            position: sticky;
            top: 100px;
            height: fit-content;
        }

        .showtime-info h3 {
            font-size: 1.3rem;
            color: var(--color-dark);
            margin-bottom: 1.5rem;
        }

        .info-item {
            padding: 1rem 0;
            border-bottom: 1px solid var(--color-light);
        }

        .info-item:last-child {
            border-bottom: none;
        }

        .info-label {
            font-size: 0.85rem;
            color: #999;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 0.5rem;
        }

        .info-value {
            font-size: 1.1rem;
            color: var(--color-dark);
            font-weight: 600;
        }

        .info-value.price {
            color: var(--color-primary);
            font-size: 1.5rem;
        }

        /* Selected Seats Display */
        .selected-seats-display {
            background: var(--color-secondary);
            padding: 1rem;
            border-radius: 8px;
            margin: 1.5rem 0;
            min-height: 50px;
        }

        .selected-seats-display p {
            margin: 0;
            color: var(--color-dark);
            font-size: 0.9rem;
            font-weight: 600;
        }

        .selected-seats-display .seats-list {
            color: var(--color-primary);
            font-weight: 700;
            margin-top: 0.5rem;
        }

        .total-price {
            background: var(--color-primary);
            color: white;
            padding: 1rem;
            border-radius: 8px;
            text-align: center;
            margin: 1.5rem 0;
        }

        .total-price .label {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .total-price .amount {
            font-size: 2rem;
            font-weight: 800;
        }

        /* Form Buttons */
        .form-actions {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .form-actions button {
            width: 100%;
            padding: 1rem;
            font-size: 1rem;
            font-weight: 600;
        }

        .btn-cancel {
            background: var(--color-light);
            color: var(--color-dark);
        }

        .btn-cancel:hover {
            background: #c8c7c6;
        }

        @media (max-width: 1024px) {
            .seats-layout {
                grid-template-columns: 1fr;
            }

            .showtime-info {
                position: static;
            }
        }

        @media (max-width: 600px) {
            .seats-layout {
                gap: 1.5rem;
            }

            .seats-container {
                padding: 1rem;
            }

            .seats-legend {
                gap: 1rem;
            }

            #seat-map {
                min-height: 300px;
                padding: 1rem;
            }

            .showtime-info {
                padding: 1.5rem;
            }
        }
    </style>

    <a href="javascript:history.back()" class="back-button">
        <span>←</span> Volver
    </a>

    <div class="seats-layout">
        <!-- Seats Selection -->
        <div class="seats-container">
            <h2>🎟️ Selecciona tus Asientos</h2>

            <div class="seats-legend">
                <div class="legend-item">
                    <div class="legend-seat available"></div>
                    <span>Disponible</span>
                </div>
                <div class="legend-item">
                    <div class="legend-seat occupied"></div>
                    <span>Ocupado</span>
                </div>
                <div class="legend-item">
                    <div class="legend-seat selected"></div>
                    <span>Seleccionado</span>
                </div>
            </div>

            <div id="seat-map"></div>
        </div>

        <!-- Showtime Info & Purchase -->
        <div class="showtime-info">
            <h3>📋 Resumen</h3>

            <div class="info-item">
                <div class="info-label">📅 Fecha</div>
                <div class="info-value">{{ \Carbon\Carbon::parse($showtime['startTime'])->format('d/m/Y') }}</div>
            </div>

            <div class="info-item">
                <div class="info-label">⏰ Hora de Inicio</div>
                <div class="info-value">{{ \Carbon\Carbon::parse($showtime['startTime'])->format('H:i') }}</div>
            </div>

            <div class="info-item">
                <div class="info-label">🏁 Hora de Fin</div>
                <div class="info-value">{{ \Carbon\Carbon::parse($showtime['endTime'])->format('H:i') }}</div>
            </div>

            <div class="info-item">
                <div class="info-label">💵 Precio por Ticket</div>
                <div class="info-value price">${{ number_format($showtime['basePrice'], 2) }}</div>
            </div>

            <div class="selected-seats-display">
                <p>Asientos Seleccionados:</p>
                <div class="seats-list" id="selectedSeatsDisplay">Ninguno</div>
            </div>

            <div class="total-price">
                <div class="label">Total a Pagar</div>
                <div class="amount" id="totalPrice">$0.00</div>
            </div>

            <form action="{{ route('event.buy-seats', request()->route('id')) }}" method="post" class="form-actions">
                @csrf
                <input type="hidden" name="seats" id="seatsInput" />
                <button type="submit" class="btn" id="submitBtn">🎫 Registrar Compra</button>
                <a href="" class="btn btn-cancel" style="text-align: center; text-decoration: none;">Cancelar</a>
            </form>
        </div>
    </div>

    @push('scripts')
        <script src="https://unpkg.com/konva@10/konva.min.js"></script>
        <script>
            const seats = @js($seats);
            const basePrice = {{ $showtime['basePrice'] }};
            const selectedSeats = [];

            // Crear Stage
            const stage = new Konva.Stage({
                container: 'seat-map',
                width: window.innerWidth > 1024 ? 700 : 500,
                height: 400
            });

            const layer = new Konva.Layer();
            stage.add(layer);

            // Obtener filas únicas
            const rowsLetters = [...new Set(seats.map(seat => String(seat.row)))].sort();
            const maxColumn = Math.max(...seats.map(seat => seat.number));

            // Espaciado de asientos
            const seatRadius = 10;
            const seatSpacing = 30;
            const rowSpacing = 40;
            const startX = 50;
            const startY = 50;

            // Función toggle de asientos
            function toggleSeat(seat, circle) {
                const index = selectedSeats.indexOf(seat.id);

                if (index !== -1) {
                    selectedSeats.splice(index, 1);
                    circle.fill('#4CAF50');
                } else {
                    selectedSeats.push(seat.id);
                    circle.fill('#FD7B41');
                }

                updateDisplay();
                layer.draw();
            }

            // Función para actualizar la pantalla
            function updateDisplay() {
                const selectedCount = selectedSeats.length;
                const totalCost = selectedCount * basePrice;

                // Actualizar asientos seleccionados
                if (selectedCount === 0) {
                    document.getElementById('selectedSeatsDisplay').textContent = 'Ninguno';
                } else {
                    document.getElementById('selectedSeatsDisplay').textContent = selectedSeats.join(', ');
                }

                // Actualizar precio total
                document.getElementById('totalPrice').textContent = '$' + totalCost.toFixed(2);

                // Actualizar input oculto
                document.getElementById('seatsInput').value = JSON.stringify(selectedSeats);

                // Habilitar/deshabilitar botón
                const submitBtn = document.getElementById('submitBtn');
                submitBtn.disabled = selectedCount === 0;
                submitBtn.style.opacity = selectedCount === 0 ? '0.5' : '1';
                submitBtn.style.cursor = selectedCount === 0 ? 'not-allowed' : 'pointer';
            }

            // Dibujar asientos
            seats.forEach(seat => {
                const rowIndex = rowsLetters.indexOf(String(seat.row));
                const x = startX + seat.number * seatSpacing;
                const y = startY + rowIndex * rowSpacing;

                const drawnSeat = new Konva.Circle({
                    x: x,
                    y: y,
                    radius: seatRadius,
                    fill: seat.status === 0 ? '#4CAF50' : '#f44336',
                    stroke: seat.status === 0 ? '#388E3C' : '#d32f2f',
                    strokeWidth: 2,
                    id: seat.id
                });

                // Agregar evento click solo a asientos disponibles
                if (seat.status === 0) {
                    drawnSeat.on('click', () => {
                        toggleSeat(seat, drawnSeat);
                    });
                    drawnSeat.on('mouseover', () => {
                        drawnSeat.scale({ x: 1.2, y: 1.2 });
                        layer.draw();
                    });
                    drawnSeat.on('mouseout', () => {
                        drawnSeat.scale({ x: 1, y: 1 });
                        layer.draw();
                    });
                    drawnSeat.cursor = 'pointer';
                }

                layer.add(drawnSeat);

                // Agregar etiqueta de asiento
                const label = new Konva.Text({
                    x: x - 12,
                    y: y - 6,
                    text: seat.number.toString(),
                    fontSize: 10,
                    fontFamily: 'Inter, sans-serif',
                    fill: '#fff',
                    align: 'center',
                    pointerEvents: 'none'
                });

                layer.add(label);
            });

            layer.draw();

            // Redimensionar canvas cuando cambia el tamaño de la ventana
            window.addEventListener('resize', () => {
                const newWidth = window.innerWidth > 1024 ? 700 : 500;
                stage.width(newWidth);
            });

            updateDisplay();
        </script>
    @endpush

@endsection

